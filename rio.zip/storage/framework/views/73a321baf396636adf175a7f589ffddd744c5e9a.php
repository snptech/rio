
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="col-md-12 grid-margin">
        <div class="row page-heading">
            <div class="col-12 col-lg-8 mb-xl-0 align-self-center align-items-center">
                <h4 class="font-weight-bold d-flex"><i class="menu-icon" data-feather="package"></i>Issed by Stores for Production (Annexure - III) </h4>
            </div>
            <div class="col-12 col-lg-2 ml-auto align-self-center align-items-end text-right">
                <a href="<?php echo e(route('issue_material_for_production_add')); ?>" class="btn btn-md btn-primary">Add New +</a>
            </div>
        </div>
    </div>
    <div class="card main-card">
        <div class="card-body">
            <div class="tbl-sticky">
            <?php if($message = Session::get('message')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                <?php if($message = Session::get('danger')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                <?php if($message = Session::get('update')): ?>
                <div class="alert alert-info alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                <table class="table table-hover table-bordered datatable">
                    <thead>
                        <tr>
                            <th>Requisition No</th>
                            <th>Material</th>
                            <th>Opening Bal</th>
                            <th>Batch No</th>
                            <th>Viscosity</th>
                            <th>Issual Date</th>
                            <th>Issued Quantity</th>

                            <th>Finished Batch No</th>
                            <th>Excess</th>
                            <th>Wastage</th>
                            <th>Returned From Day Store</th>
                            <th>Closing Bbalance Qty</th>
                            <th>Dispensed By</th>
                            <th>Remark</th>
                            <th>Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php if(count($issue_material)): ?>
                        <?php $__currentLoopData = $issue_material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($temp->requisition_no); ?></td>
                            <td> <?php echo e($temp->material_name); ?></td>
                            <td> <?php echo e($temp->opening_bal); ?></td>
                            <td> <?php echo e($temp->rbatch); ?></td>
                            <td> <?php echo e($temp->viscosity); ?></td>
                            <td> <?php echo e($temp->issual_date); ?></td>
                            <td> <?php echo e($temp->issued_quantity); ?></td>
                            <td> <?php echo e($temp->finished_batch_no); ?></td>
                            <td> <?php echo e($temp->excess); ?></td>
                            <td> <?php echo e($temp->wastage); ?></td>
                            <td> <?php echo e($temp->returned_from_day_store); ?></td>
                            <td> <?php echo e($temp->closing_balance_qty); ?></td>
                            <td> <?php echo e($temp->name); ?></td>
                            <td> <?php echo e($temp->remark); ?></td>
                            <td>
                           <!-- <a href="<?php echo e(route('view_issue_material',['id'=>$temp->id])); ?>" class="btn action-btn" data-toggle="tooltip" data-placement="top" title="View"><i data-feather="eye"></i></a>-->
                           <a href="#" class="btn action-btn" data-toggle="modal" data-target="#viewsupplier" title="View" onclick="viewsupp(<?php echo e($temp->id); ?>)"><i data-feather="eye"></i></a>

                            </td>

                         </tr>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush("models"); ?>
<div class="modal fade show" id="viewsupplier" tabindex="-1" aria-labelledby="checkQuntityLabel" aria-modal="true">
<div class="modal-dialog modal-lg">
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="checkQuntityLabel">Supplier Details</h5>
      <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close">x</button>
    </div>
    <div class="modal-body">

    </div>
  </div>
</div>
</div>
<?php $__env->stopPush(); ?>
<?php $__env->startPush("scripts"); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo e(asset('assets/mdbootstrap4/mdb.min.js')); ?>"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
  <!-- End custom js for this page-->
  <script>
      feather.replace()
    $(document).ready(function() {
        $('.datatable').DataTable();
    });

    function viewsupp(id)
    {
       $.ajax({
         url:'<?php echo e(route("view_issue_material")); ?>',
         data:{
        "_token": "<?php echo e(csrf_token()); ?>",
        "id": id
        },
        datatype:'json',
         method:"POST"
       }).done(function( html ) {

          $(".modal-body").html(html.html);
      });
    }

  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rio\resources\views/issue_material_for_production.blade.php ENDPATH**/ ?>