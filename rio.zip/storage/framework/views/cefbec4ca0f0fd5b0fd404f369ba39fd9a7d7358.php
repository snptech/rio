<div class="form-row">
    <div class="col-12">
        <h3>Dispatch Finished Goods</h3>
    </div>
    <div class="col-12 table-responsive">
        <table class="table table-hover table-bordered">
            <tr>
                <th >Date</th>
                <td><?php echo e(date("d/m/Y ",strtotime($dispacth_view->created_at))); ?></td>
            </tr>
            <tr>
                <th >Party Name</th>
                <td><?php echo e($dispacth_view->company_name); ?></td>
            </tr>
            <tr>
                <th >Product Name</th>
                <td><?php echo e($dispacth_view->material_name); ?></td>
            </tr>
            <tr>
                <th >Invoice No.</th>
                <td><?php echo e($dispacth_view->invoice_no); ?></td>
            </tr>
            <tr>
                <th >Batch No.</th>
                <td><?php echo e($dispacth_view->batch_no); ?></td>
            </tr>
            <tr>
                <th >Grade</th>
                <td><?php echo e($dispacth_view->grades_name); ?></td>
            </tr>
            <tr>
                <th >Viscosity</th>
                <td><?php echo e($dispacth_view->viscosity); ?></td>
            </tr>
            <tr>
                <th colspan="2">Total Drums</th>
            </tr>
            <tr>
                <th>200Kg</th>
                <td><?php echo e($dispacth_view->total_no_of_200kg_drums); ?></td>
            </tr>
            <tr>
                <th>50Kg</th>
                <td><?php echo e($dispacth_view->total_no_of_50kg_drums); ?></td>
            </tr>
            <tr>
                <th>30Kg</th>
                <td><?php echo e($dispacth_view->total_no_of_30kg_drums); ?></td>
            </tr>
            <tr>
                <th>5Kg</th>
                <td><?php echo e($dispacth_view->total_no_of_5kg_drums); ?></td>
            </tr>
            <tr>
                <th>Total No. of Fiber Board Drums</th>
                <td><?php echo e($dispacth_view->total_no_of_fiber_board_drums); ?></td>
            </tr>


            <tr>
                <th>Total Quantity (Kg)</th>
                <td><?php echo e($dispacth_view->total_no_qty); ?></td>
            </tr>
            <tr>
                <th>Seal No.</th>
                <td><?php echo e($dispacth_view->seal_no); ?></td>

            </tr>
            <tr>
                <th>Remark</th>
                <td><?php echo e($dispacth_view->remark); ?></td>
            </tr>
            <tr>
                <th>Dispatch By</th>
                <td><?php echo e($dispacth_view->name); ?></td>
            </tr>

        </table>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\rio\resources\views/dispacth_view.blade.php ENDPATH**/ ?>