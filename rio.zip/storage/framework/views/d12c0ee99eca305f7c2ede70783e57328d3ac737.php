	<div class="form-row" >
				<div class="col-12">
					<h3>Supplier Details</h3>
				</div>
				<div class="col-12 table-responsive">
                     <table class="table table-hover table-bordered">
                         <tr>
                             <th>Supplier Name</th>
                             <td><?php echo e($supllier->name); ?></td>
                         </tr>
                         <tr>
                            <th>City</th>
                            <td><?php echo e($supllier->city); ?></td>
                        </tr>
                        <tr>
                            <th>State</th>
                            <td><?php echo e($supllier->state); ?></td>
                        </tr>
                        <tr>
                            <th>Address</th>
                            <td><?php echo e($supllier->address); ?></td>
                        </tr>
                        <tr>
                            <th>Company Name</th>
                            <td><?php echo e($supllier->company_name); ?></td>
                        </tr>
                        <tr>
                            <th>Contact Person Name</th>
                            <td><?php echo e($supllier->contact_per_name); ?></td>
                        </tr>

                        <tr>
                            <th>Contact Number</th>
                            <td><?php echo e($supllier->contact_no); ?></td>
                        </tr>
                        <tr>
                            <th>GST Number</th>
                            <td><?php echo e($supllier->gst_no); ?></td>
                        </tr>
                        <tr>
                            <th>Pan Number</th>
                            <td><?php echo e($supllier->pan_no); ?></td>
                        </tr>
                     </table>
				</div>
			</div>
<?php /**PATH C:\xampp\htdocs\rio\resources\views/master/supplier/view.blade.php ENDPATH**/ ?>