
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12 grid-margin">
            <div class="row page-heading">
                <div class="col-12 col-lg-8 mb-xl-0 align-self-center align-items-center">
                    <h4 class="font-weight-bold d-flex"><i class="menu-icon" data-feather="package"></i>Finished Goods Inward (Annexure - I) - New Stock</h4>
                </div>
                <div class="col-12 col-lg-2 ml-auto align-self-center align-items-end text-right">
                    <a href="<?php echo e(route('new_stock_add')); ?>" class="btn btn-md btn-primary">Add New +</a>
                </div>
            </div>
        </div>
    </div>
    <div class="card main-card">
        <div class="card-body">
            <div class="tbl-sticky">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                <?php if($message = Session::get('danger')): ?>
                <div class="alert alert-danger alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                <?php if($message = Session::get('update')): ?>
                <div class="alert alert-info alert-block">
                    <button type="button" class="close" data-dismiss="alert">×</button>
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table table-hover table-bordered datatable">
                        <thead>
                            <tr>
                                <th rowspan="2">Date</th>
                                <th rowspan="2">Product Name</th>
                                <th rowspan="2">Batch No</th>
                                <th rowspan="2">Grade</th>
                                <th rowspan="2">Viscosity</th>
                                <th rowspan="2">Mfg. Date</th>
                                <th rowspan="2">Expiry Retest Date</th>
                                <th colspan="5">Total No. of Drumbs</th>
                                <th rowspan="2">Total Quantity (Kg.)</th>
                                <th rowspan="2">AR No.</th>
                                <th rowspan="2">Approval Date</th>
                                <th rowspan="2">Received by</th>
                                <th rowspan="2">Action</th>
                            </tr>
                            <tr>
                                <th>200 Kg</th>
                                <th>50 Kg</th>
                                <th>30 Kg</th>
                                <th>5 Kg</th>
                                <th>Fiber board</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(count($inward_goods)): ?>
                            <?php $__currentLoopData = $inward_goods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($temp->inward_date); ?></td>
                                <td><?php echo e($temp->material_name); ?></td>
                                <td><?php echo e($temp->batch_no); ?></td>
                                <td><?php echo e($temp->grade); ?></td>
                                <td><?php echo e($temp->viscosity); ?></td>
                                <td><?php echo e($temp->mfg_date); ?></td>
                                <td><?php echo e($temp->expiry_ratest_date); ?></td>
                                <td><?php echo e($temp->total_no_of_200kg_drums); ?></td>
                                <td><?php echo e($temp->total_no_of_50kg_drums); ?></td>
                                <td><?php echo e($temp->total_no_of_30kg_drums); ?></td>
                                <td><?php echo e($temp->total_no_of_5kg_drums); ?></td>
                                <td><?php echo e($temp->total_no_of_fiber_board_drums); ?></td>
                                <td><?php echo e($temp->total_quantity); ?></td>
                                <td><?php echo e($temp->ar_no); ?></td>
                                <td><?php echo e($temp->approval_data); ?></td>
                                <td><?php echo e($temp->name); ?></td>
                                <td>
                                    <a class="actions"><a href="#" class="btn action-btn" data-toggle="modal" data-target="#viewnewstock" title="View" onclick="viewstock(<?php echo e($temp->id); ?>)"><i data-feather="eye"></i></a>

                                </td>

                            </tr>


                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>

    </div>

    <?php $__env->stopSection(); ?>
    <?php $__env->startPush("models"); ?>
    <div class="modal fade show" id="viewnewstock" tabindex="-1" aria-labelledby="checkQuntityLabel" aria-modal="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="checkQuntityLabel">New Stock Details</h5>
                    <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close">x</button>
                </div>
                <div class="modal-body">

                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush("scripts"); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css" />
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

    <script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo e(asset('assets/mdbootstrap4/mdb.min.js')); ?>"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    <!-- End custom js for this page-->

    <script>
        $('.datatable').DataTable({});

        function viewstock(id) {
            $.ajax({
                url: '<?php echo e(route("viewstock")); ?>',
                data: {
                    "_token": "<?php echo e(csrf_token()); ?>",
                    "id": id
                },
                datatype: 'json',
                method: "POST"
            }).done(function(html) {

                $(".modal-body").html(html.html);
            });
        }
    </script>
    <?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rio\resources\views/new_stock.blade.php ENDPATH**/ ?>