
<?php $__env->startSection('title', 'Create Department'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12 grid-margin">
            <div class="row page-heading">
                <div class="col-12 col-xl-8 mb-xl-0 align-self-center align-items-center">
                    <h4 class="font-weight-bold d-flex"><i class="menu-icon" data-feather="layers"></i>Edit Department</h4>

                </div>
            </div>
        </div>
    </div>
    <div class="card main-card">
        <div class="card-body">
            <form class="login100-form validate-form" action="<?php echo e(route('department-update',["id"=>$department->id])); ?>" method="POST" id="departmentForm">
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                        <div class="form-group">
                            <label for="rno">Deparment Name</label>
                            <input type="text" class="form-control" name="department" id="department" placeholder="Department Name" value="<?php echo e(old("department")?old("department"):$department->department); ?>">
                            <?php if($errors->has('department')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('department')); ?></span>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-12 col-md-6 col-lg-12 col-xl-6">
                        <div class="form-group">
                            <label for="from">Publish</label>
                            <div>
                                <?php
                                    $pulishy = "";
                                    $pulishn = "";
                                    if(old('publish') ==1 || $department->publish ==1)
                                        $pulishy = "checked";
                                    elseif(old('publish') == 0 || $department->publish ==0)
                                    {
                                        $pulishn = "checked";
                                    }
                                    else {
                                        $pulishy = "checked";
                                    }
                                ?>
                                <div class="form-check form-check-inline">
                                    <input
                                      class="form-check-input"
                                      type="radio"
                                      name="publish"
                                      id="inlineRadio1"
                                      value="1"
                                     <?php echo e($pulishy); ?>

                                    />
                                    <label class="form-check-label" for="inlineRadio1"> Yes</label>
                                  </div>

                                  <div class="form-check form-check-inline">
                                    <input
                                      class="form-check-input"
                                      type="radio"
                                      name="publish"
                                      id="inlineRadio2"
                                      value="0"
                                      <?php echo e($pulishn); ?>

                                    />
                                    <label class="form-check-label" for="inlineRadio2">No</label>
                                  </div>

                                  <?php if($errors->has('publish')): ?>
                                    <span class="text-danger"><?php echo e($errors->first('publish')); ?></span>
                                  <?php endif; ?>


                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-row">
                    <div class="col-12">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-md ml-0 form-btn">Submit</button><button type="reset"
                                class="btn btn-light btn-md form-btn">Clear</button>
                        </div>
                    </div>
                </div>
                </form>
        </div>
    </div>



<?php $__env->stopSection(); ?>
<?php $__env->startPush("scripts"); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
<script>
    $(document).ready(function() {
  $("#departmentForm").validate({
    rules: {
      department : {
        required: true,
        minlength: 3
      },
      publish: {
        required: true,

      }
    },
    messages : {
    department: {
        required: "Field Department is required.",
        minlength: "Deparment should be at least 3 characters"
      },
      publish: {
        required: "Please select publish option",

      }
    }
  });
});

    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rio\resources\views/master/department/edit.blade.php ENDPATH**/ ?>