;
<?php $__env->startSection("title","Role Master"); ?>
<?php $__env->startSection("content"); ?>
<div class="row">
    <div class="col-md-12 grid-margin">
      <div class="row page-heading">
        <div class="col-12 col-lg-8 mb-xl-0 align-self-center align-items-center">
          <h4 class="font-weight-bold d-flex"><i class="menu-icon" data-feather="package"></i>Actions</h4>
        </div>
        <div class="col-12 col-lg-2 ml-auto align-self-center align-items-end text-right">
          <a href="<?php echo e(route("new-action")); ?>" class="btn btn-md btn-primary">Add New +</a>
        </div>
      </div>
    </div>
  </div>
  <div class="card main-card">
    <div class="card-body">
       <div class="tbl-sticky">
        <?php if(Session::has('error')): ?>
        <div id="" class="alert alert-danger col-md-12"><?php echo Session::get('error'); ?>

        </div>
        <?php endif; ?>
        <?php if(Session::has('message')): ?>
            <div id="" class="alert alert-success col-md-12"><?php echo Session::get('message'); ?>

            </div>
        <?php endif; ?>
            <table class="table table-hover table-bordered datatable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Action</th>
                        <th>Controller</th>
                        <th align="center">Publish</th>
                        <th>Created At</th>
                        <th>Updated At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($actions)): ?>
                        <?php ($i=1); ?>
                        <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i); ?></td>
                        <td><?php echo e($val->action); ?></td>
                        <td><?php echo e($val->controller_name); ?></td>
                        <td align="center"> <?php if($val->publish ==1): ?> <i data-feather="eye" style="color: green"></i> <?php else: ?> <i data-feather="eye-off" style="color: red"></i> <?php endif; ?></td>
                        <td><?php echo e(date("d/m/Y H:i",strtotime($val->created_at))); ?></td>

                        <td><?php echo e(date("d/m/Y H:i",strtotime($val->created_at))); ?></td>

                        <td class="actions"><a href="<?php echo e(route("edit-action",["id"=>$val->id])); ?>" class="btn action-btn" data-toggle="tooltip" title="Edit"><i data-feather="edit-3"></i></a><a href="#" class="btn action-btn" data-toggle="tooltip" class="remove" data-href="" title="Delete" onclick="remove('<?php echo e(route("delete-action",["id"=>$val->id])); ?>')"><i data-feather="trash"></i></a></td>
                    </tr>
                        <?php ($i++); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>


                </tbody>
            </table>
        </div>

    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush("scripts"); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/dataTables.bootstrap4.min.css" />
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
<script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js"></script>

<script src="https://cdn.datatables.net/1.10.24/js/dataTables.bootstrap4.min.js"></script>
  <script src="<?php echo e(asset('assets/mdbootstrap4/mdb.min.js')); ?>"></script>
  <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
  <!-- End custom js for this page-->
  <script>
    $(document).ready(function() {
        $('.datatable').DataTable();
    } );
    function remove(url) {

        const swalWithBootstrapButtons = Swal.mixin({
        customClass: {
            confirmButton: 'btn btn-success',
            cancelButton: 'btn btn-danger'
        },
        buttonsStyling: false
        })

        swalWithBootstrapButtons.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        cancelButtonText: 'No, cancel!',
        reverseButtons: true
        }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = url;
            swalWithBootstrapButtons.fire(
            'Deleted!',
            'Your record has been deleted.',
            'success'
            )
        } else if (
            /* Read more about handling dismissals below */
            result.dismiss === Swal.DismissReason.cancel
        ) {
            swalWithBootstrapButtons.fire(
            'Cancelled',
            'Your imaginary file is safe :)',
            'error'
            )
        }
        })
    }
  </script>
  <?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rio\resources\views/master/action/index.blade.php ENDPATH**/ ?>