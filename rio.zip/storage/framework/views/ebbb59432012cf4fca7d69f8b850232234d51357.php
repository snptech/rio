<div class="form-row" >
				<div class="col-12">
					<h3>ssual by stores for production  Details</h3>
				</div>
				<div class="col-12 table-responsive">
                     <table class="table table-hover table-bordered">
                         <tr>
                             <th>Requisition No</th>
                             <td><?php echo e($IssualStores->requisition_no); ?></td>
                         </tr>
                         <tr>
                            <th>Opening Balance</th>
                            <td><?php echo e($IssualStores->opening_balance); ?></td>
                        </tr>
                        <tr>
                            <th>Issual Date</th>
                            <td><?php echo e($IssualStores->issual_date); ?></td>
                        </tr>
                        <tr>
                            <th>Product Name</th>
                            <td><?php echo e($IssualStores->material_name); ?></td>
                        </tr>
                        <tr>
                            <th>Batch No</th>
                            <td><?php echo e($IssualStores->batch_no); ?></td>
                        </tr>
                        <tr>
                            <th>Quantity</th>
                            <td><?php echo e($IssualStores->quantity); ?></td>
                        </tr>

                        <tr>
                            <th>For FG Batch No</th>
                            <td><?php echo e($IssualStores->for_fg_batch_no); ?></td>
                        </tr>
                        <tr>
                            <th>Returned From Day Sstorer</th>
                            <td><?php echo e($IssualStores->returned_from_day_store); ?></td>
                        </tr>
                        <tr>
                            <th>Dispensed by</th>
                            <td><?php echo e($IssualStores->dispensed_by); ?></td>
                        </tr>
                        <tr>
                            <th>Remark</th>
                            <td><?php echo e($IssualStores->remark); ?></td>
                        </tr>
                     </table>
				</div>
			</div>
<?php /**PATH C:\xampp\htdocs\rio\resources\views/view_issual_stores.blade.php ENDPATH**/ ?>