<?php $__env->startSection("title","Dashboard"); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 grid-margin">
      <div class="row page-heading">
        <div class="col-12 col-xl-8 mb-xl-0 align-self-center align-items-center d-flex">
          <h4 class="font-weight-bold"><i class="menu-icon" data-feather="home"></i>Coming Soon</h4>
        </div>
      </div>
    </div>
  </div>
  <div class="row dashboard">
    <div class="col-12 col-lg-8">
        <h1>Coming Soon !!! </h1>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rio\resources\views/comming-soon.blade.php ENDPATH**/ ?>