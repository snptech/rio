<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="row">
        <div class="col-md-12 grid-margin">
            <div class="row page-heading">
                <div class="col-12 col-xl-8 mb-xl-0 align-self-center align-items-center">
                    <h4 class="font-weight-bold d-flex"><i class="menu-icon" data-feather="package"></i>Goods Receipt Note (Packing Material)</h4>
                </div>
            </div>
        </div>
    </div>
    <div class="card main-card">
        <div class="card-body">
            <form id="inward_packing_material" name="inward_packing_material" method="post" action="<?php echo e(route("inwardpackingrawmaterial-save")); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-row">
                    <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                        <div class="form-group">
                            <label for="from">From</label>
                            <input type="text" class="form-control" name="received_from" id="received_from" placeholder="Store" value="Store" readonly>
                            <?php if($errors->has('dispath_no')): ?>
                            <span class="text-danger"><?php echo e($errors->first('received_from')); ?></span>
                          <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                        <div class="form-group">
                            <label for="to">TO</label>
                            <input type="text" class="form-control" name="received_to" id="received_to" placeholder="Quality Control and Purchase" value="Quality Control and Purchase" readonly>.
                            <?php if($errors->has('received_to')): ?>
                            <span class="text-danger"><?php echo e($errors->first('received_to')); ?></span>
                          <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                        <div class="form-group">
                            <label for="receiptDate">Date of Receipt</label>
                            <input type="date" class="form-control calendar" name="date_of_receipt" id="date_of_receipt" placeholder="DD-MM-YYYY" value="<?php echo e(old("date_of_receipt")); ?>">
                            <?php if($errors->has('date_of_receipt')): ?>
                            <span class="text-danger"><?php echo e($errors->first('date_of_receipt')); ?></span>
                          <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                    </div>
                    <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                        <div class="form-group">
                            <label for="ManufacturerName">Name of Manufacturer</label>
                            <?php echo e(Form::select("manufacturer",$manufacturer,old("manufacturer"),array("class"=>"form-control select","id"=>"manufacturer","placeholder"=>"Name of Manufacturer"))); ?>

                            <?php if($errors->has('manufacturer')): ?>
                          <span class="text-danger"><?php echo e($errors->first('manufacturer')); ?></span>
                          <?php endif; ?>

                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                        <div class="form-group">
                            <label for="SupplierName">Name of Supplier</label>
                            <?php echo e(Form::select("supplier",$supplier,old("supplier"),array("class"=>"form-control select","id"=>"manufacturer","placeholder"=>"Name of Supplier"))); ?>

                            <?php if($errors->has('supplier')): ?>
                          <span class="text-danger"><?php echo e($errors->first('supplier')); ?></span>
                          <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                        <div class="form-group">
                            <label for="invoiceNo">Invoice No.</label>
                            <input type="text" class="form-control" name="invoice_no" id="invoice_no" placeholder="Invoice No" value="<?php echo e(old("invoice_no")); ?>">
                            <?php if($errors->has('invoice_no')): ?>
                          <span class="text-danger"><?php echo e($errors->first('invoice_no')); ?></span>
                          <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 col-lg-6 col-xl-6">
                        <div class="form-group">
                            <label for="receiptNo">Goods Receipt No.</label>
                            <input type="text" class="form-control" name="goods_receipt_no" id="goods_receipt_no" value="<?php echo e(old("goods_receipt_no")); ?>"placeholder="GRM/RM/Receipt No.">
                            <?php if($errors->has('goods_receipt_no')): ?>
                          <span class="text-danger"><?php echo e($errors->first('goods_receipt_no')); ?></span>
                          <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 col-md-12 col-lg-12 col-xl-12">
                        <div class="form-group input_fields_wrap" id="MaterialReceived">
                            <label class="control-label d-flex">Details of Material Received
                                <div class="input-group-btn">
                                    <button class="btn btn-dark add-more add_field_button" type="button">Add More +</button>
                                </div>
                            </label>
                            <div class="row add-more-wrap after-add-more m-0 mb-4">
                                <span class="add-count">1</span>
                                <div class="col-12 col-md-6">
                                    <div class="form-group">
                                        <label for="packingMaterialName">Packing Material Name</label>
                                        <?php echo e(Form::select("material[]",$rawmaterial,isset(old("material")[0])?old("material")[0]:"",array("class"=>"form-control select","id"=>"material","placeholder"=>"Name of Material"))); ?>

                                        <?php if($errors->has('material')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('material')); ?></span>
                                        <?php endif; ?>

                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="form-group">
                                        <label for="Quantity">Total Quantity Received (Nos.)</label>
                                        <input type="text" class="form-control" name="total_qty[]" id="total_qty" placeholder="Quantity" value="<?php echo e(old("total_qty")); ?>">
                                        <?php if($errors->has('total_qty')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('total_qty')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-12 col-md-6">
                                    <div class="form-group">
                                        <label for="ARNo">AR No. / Date</label>
                                        <input type="text" class="form-control" name="ar_no_date[]" id="ar_no_date" placeholder="AR No. / Date" value="<?php echo e(old("ar_no_date")); ?>">
                                        <?php if($errors->has('ar_no_date')): ?>
                                        <span class="text-danger"><?php echo e($errors->first('ar_no_date')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label for="Remark">Note / Remark</label>
                            <textarea class="form-control" name="remark" id="remark" placeholder="Note / Remark"></textarea>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-md ml-0 form-btn">Submit</button>
                            <button type="reset" class="btn btn-light btn-md form-btn">Clear</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush("scripts"); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
<script>
    feather.replace()
    /*$(document).ready(function() {
		var c = 1;
      $(".add-more").click(function(){
          var html = $(".copy").html();
          $(".after-add-more").after(html);
      });
      $("body").on("click",".remove",function(){
          $(this).parents(".add-more-new").remove();
      });
    });*/
    $(document).ready(function() {
        var max_fields = 15; //maximum input boxes allowed
        var wrapper = $(".input_fields_wrap"); //Fields wrapper
        var add_button = $(".add_field_button"); //Add button ID

        var x = 1; //initlal text box count
        $(add_button).click(function(e) { //on add input button click
            e.preventDefault();
            if (x < max_fields) { //max input box allowed
                x++; //text box increment
                $(wrapper).append('<div class="row add-more-wrap add-more-new m-0 mb-4"><span class="add-count">' + x + '</span><div class="input-group-btn"><button class="btn btn-danger remove_field" type="button"><i class="icon-remove" data-feather="x"></i></button></div><div class="col-12 col-md-6"><div class="form-group"><label for="MaterialName[' + x + ']">Raw Material Name</label><?php echo e(Form::select("material[]",$rawmaterial,old("material"),array("class"=>"form-control select","id"=>"material'+x+'","placeholder"=>"Name of Material"))); ?></div></div><div class="col-12 col-md-6"><div class="form-group"><label for="Quantity[' + x + ']">Quantity Received (Kg)</label><input type="text" class="form-control" name="total_qty[]" id="total_qty[' + x + ']" placeholder="Quantity"></div></div><div class="col-12 col-md-6"><div class="form-group"><label for="ARNo[' + x + ']">AR No. / Date</label><input type="text" class="form-control" name="ar_no_date[]" id="ar_no_date[' + x + ']" placeholder="AR No. / Date"></div></div></div>'); //add input box
            }
            feather.replace()
        });

        $(wrapper).on("click", ".remove_field", function(e) { //user click on remove text
            e.preventDefault();
            $(this).parents('div.row').remove();
            x--;
        })
    });
</script>
<script>
    $(document).ready(function() {
        $("#inward_packing_material").validate({
            rules: {
                received_from: "required",
                received_to: "required",
                date_of_receipt: "required",
                material: "required",
                manufacturer: "required",
                supplier: "required",

                invoice_no: "required",
                goods_receipt_no: "required",

                "total_qty[]": "required",
                "ar_no_date[]": "required",
                "material[]": "required",

            },
            messages: {
                inward_no: "Please  Enter The Inward No",
                received_from: "Please  Enter The Received from",
                received_to: "Please  Enter The Received To",
                date_of_receipt: "Please  Enter The Date Of Receipt",
                manufacturer: "Please  Enter The Manufacturer",
                supplier: "Please  Enter The Supplier",
                invoice_no: "Please  Enter The Invoice no",
                goods_receipt_no: "Please  Enter The Goods Receipt No",
                "total_qty[]": "Please  Enter The total qty",
                "material[]": "Please  select The Material",
                "ar_no_date": "Please  Enter The Ar No Date",

            },
        });

    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rio\resources\views/add_inward_packing_material.blade.php ENDPATH**/ ?>